# Parsite
#### Video Demo:  https://youtu.be/CLWLUuKzHLk
#### Description:
The main idea of this project is to help people find apartments much faster by collecting ads from different websites info one database. To do this, I have created 3 different classes using Python for such websites as Avito, Domclick, Cian in which I used Selenium, Beautifulsoup, Requests, Json  libraries, therefore I have parsed relevant information from every page and added key information to database. 

By using this script all these functions are performed automatically. During the process I faced several problems. For instance, 403 error and defence system, but I was able to fix it, as a result chrome launches not like a software but as a real user. However,  it was really difficult to access to Domclick website, therefore I couldn't have parsed it yet. Once a week table from this database constantly updating. From the user perspective, when the user fill the query form such as filters, he gets relevant information from all 3 websites.

All advertisement cards contain id, link, title, price, address, metro station, description, image, website columns and the "query_result" page demonstrates these cards with these information.

<b>My project is made only for informational purpose, it shows  a post template with a link to the original page of the website</b>. By clicking the link you will be directed to the original page on definite website.

Another main option is created ads page: user who logged in has an opportunity to make his/her own posts (e.x. car or apartment advertisement).
After creating, on the main page you will be able to see these posts which you or someone else created.
Client can also add advertisement to favorite by clicking "heart" symbol at the right top corner and delete them by clicking the same button but at the <b>favorite page</b>.

In addition, user have their own page (profile) named "account" where user's and whole site's information are demonstrated.

This system is not created for commercial using but only as an educational and informational example of software.











