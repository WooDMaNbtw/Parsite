//var elements = document.querySelectorAll('.desc');
//
//elements.forEach(function(element) {
//    var maxLength = 400;
//    var text = element.innerHTML;
//
//    if (text.length > maxLength) {
//        element.innerHTML = text.substring(0, maxLength) + '...';
//    }
//});
