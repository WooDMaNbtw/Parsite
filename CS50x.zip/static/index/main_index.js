//const fav_btn = document.getElementById("fav");
//
//fav_btn.addEventListener("click", function () {
//    alert("Item was added to favorite!")
//    console.log(2);
//});
//let isButtonGrey = true; // Переменная для отслеживания цвета кнопки
//const heart = document.querySelector("span-fav")
//fav_btn.addEventListener("click", function () {
//  if (isButtonGrey) {
//    heart.style.color = "red";
//  } else {
//    heart.style.color = "grey";
//  }
//
//  // Инвертируем значение переменной для следующего клика
//  isButtonGrey = !isButtonGrey;
//});